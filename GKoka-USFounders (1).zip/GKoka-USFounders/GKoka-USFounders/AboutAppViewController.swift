//
//  AboutAppViewController.swift
//  GKoka-USFounders
//
//  Created by Gayatri on 01/10/18.
//  Copyright © 2018 Naga Gayatri Koka. All rights reserved.
/*
 Author:     Naga Gayatri Koka
 Z-ID:       Z1823454
 Course:     CSCI 521, Fall 2018
 Description: This is third app to develop by IOS Course students. The description is as follows
 1) This app uses tableViewController to display 7 US founders image, name and years of work. It displays the detail in the form of a table where each founder details displayed in each row. When a row is selected then the view will transfer to a detail view.
 2) Detail view consists of details about the Founder selected. It displays Image,title, political party and spouse name. It also has info light button on the bottom right cornor when this button is pressed the view will transfer to about app view.
 3) The about app has Done button, text view and about author button. When done button is pressed the view will transfer to the detail view. The text view consists of details about the application. when about author button is pressed view will transfer to about author view.
 4) About author view has webkit view which displays details of author who developed the application. Those details are presented in the form of a webpage.
 
 Due: Friday, 10/05/2018 11:59 pm
 */

import UIKit

/* AboutAppViewController will control the data flow in about app view. This view consists of details about the app and the version. It also has a button called About Author which when clicked will display the about author view. It has a done button which when pressed will dismiss the about app view.
 */
class AboutAppViewController: UIViewController
{
    //doneRightBarButton is an IBAction for the done button in the view
    @IBAction func doneRightBarButton(_ sender: UIBarButtonItem)
    {
        //It will dismiss the view
        self.dismiss(animated: true, completion: nil)
    }
    
    /*
     This function pushes the view controller when author view button is pressed.
     */
    @IBAction func aboutAuthorViewButton(_ sender: UIButton)
    {
        //Finding the about author view controller in the storyboard and pushing the present view to author view
        let storyBoard = UIStoryboard(name: "Main", bundle: nil)
        
        let destinationVC = storyBoard.instantiateViewController(withIdentifier: "AboutAuthorViewController") as! AboutAuthorViewController
        
        self.navigationController?.pushViewController(destinationVC, animated: false)
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
