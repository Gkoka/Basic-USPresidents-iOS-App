//
//  DetailViewController.swift
//  GKoka-USFounders
//
//  Created by Gayatri on 01/10/18.
//  Copyright © 2018 Naga Gayatri Koka. All rights reserved.
/*
 Author:     Naga Gayatri Koka
 Z-ID:       Z1823454
 Course:     CSCI 521, Fall 2018
 Description: This is third app to develop by IOS Course students. The description is as follows
 1) This app uses tableViewController to display 7 US founders image, name and years of work. It displays the detail in the form of a table where each founder details displayed in each row. When a row is selected then the view will transfer to a detail view.
 2) Detail view consists of details about the Founder selected. It displays Image,title, political party and spouse name. It also has info light button on the bottom right cornor when this button is pressed the view will transfer to about app view.
 3) The about app has Done button, text view and about author button. When done button is pressed the view will transfer to the detail view. The text view consists of details about the application. when about author button is pressed view will transfer to about author view.
 4) About author view has webkit view which displays details of author who developed the application. Those details are presented in the form of a webpage.
 
 Due: Friday, 10/05/2018 11:59 pm
 */

import UIKit

/* DetailViewController represents the detail view. This controller will control the data flow. It has outlets of dtvImage, dtvParty, dtvSpouse and dtvTitle. These outlets are used to set the data about a selected founder.
 */
class DetailViewController: UIViewController {
    
    //Outlets to display image, political party, spouse name and title
    @IBOutlet weak var dtvImage: UIImageView!
    @IBOutlet weak var dtvParty: UILabel!
    @IBOutlet weak var dtvSpouse: UILabel!
    @IBOutlet weak var dtvTitle: UILabel!
    
    // Variables to heold data passed from the TableViewController
    var tvPresidentImage:String!    //president image
    var tvTitle:String!         //title
    var tvParty:String!         //political party
    var tvSpouse:String!        //spouse name
    var tvPresidentName:String! //president name
    
    //showAboutAppView is a IBAction function where when the info light button is clicked the view will transfer to about app view.
    @IBAction func showAboutAppView(_ sender: UIButton)
    {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "AboutAppNavigationController") as! UINavigationController
        self.present(controller, animated: false, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Setting the title of detail view to the name
        navigationItem.title = tvPresidentName;

        // Place sent data into their outlets
        dtvImage.image = UIImage(named: tvPresidentImage)
        dtvTitle.text = tvTitle
        dtvParty.text = tvParty
        dtvSpouse.text = tvSpouse
        
    }


}
