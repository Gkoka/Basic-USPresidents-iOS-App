//
//  TableViewCell.swift
//  GKoka-USFounders
//
//  Created by Gayatri on 01/10/18.
//  Copyright © 2018 Naga Gayatri Koka. All rights reserved.
/*
 Author:     Naga Gayatri Koka
 Z-ID:       Z1823454
 Course:     CSCI 521, Fall 2018
 Description: This is third app to develop by IOS Course students. The description is as follows
 1) This app uses tableViewController to display 7 US founders image, name and years of work. It displays the detail in the form of a table where each founder details displayed in each row. When a row is selected then the view will transfer to a detail view.
 2) Detail view consists of details about the Founder selected. It displays Image,title, political party and spouse name. It also has info light button on the bottom right cornor when this button is pressed the view will transfer to about app view.
 3) The about app has Done button, text view and about author button. When done button is pressed the view will transfer to the detail view. The text view consists of details about the application. when about author button is pressed view will transfer to about author view.
 4) About author view has webkit view which displays details of author who developed the application. Those details are presented in the form of a webpage.
 
 Due: Friday, 10/05/2018 11:59 pm
 */

import UIKit

/*TableViewCell represents the table cell "CELL". This cell consists of outlets created to identify the imageView, title and subTitle in the cell
 */
class TableViewCell: UITableViewCell {
    
    //Outlets to display park cell image, name and years
    @IBOutlet weak var cellImageView: UIImageView! //image of the president
    @IBOutlet weak var cellTitle: UILabel!  //name of the president
    @IBOutlet weak var cellSubTitle: UILabel!   //years in office
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
