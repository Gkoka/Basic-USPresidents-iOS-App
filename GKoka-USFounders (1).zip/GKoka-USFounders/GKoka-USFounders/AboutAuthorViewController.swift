//
//  AboutAuthorViewController.swift
//  GKoka-USFounders
//
//  Created by Gayatri on 01/10/18.
//  Copyright © 2018 Naga Gayatri Koka. All rights reserved.
/*
 Author:     Naga Gayatri Koka
 Z-ID:       Z1823454
 Course:     CSCI 521, Fall 2018
 Description: This is third app to develop by IOS Course students. The description is as follows
 1) This app uses tableViewController to display 7 US founders image, name and years of work. It displays the detail in the form of a table where each founder details displayed in each row. When a row is selected then the view will transfer to a detail view.
 2) Detail view consists of details about the Founder selected. It displays Image,title, political party and spouse name. It also has info light button on the bottom right cornor when this button is pressed the view will transfer to about app view.
 3) The about app has Done button, text view and about author button. When done button is pressed the view will transfer to the detail view. The text view consists of details about the application. when about author button is pressed view will transfer to about author view.
 4) About author view has webkit view which displays details of author who developed the application. Those details are presented in the form of a webpage.
 
 Due: Friday, 10/05/2018 11:59 pm
 */

//Importing the header files required
import UIKit
import WebKit

/* AboutAuthorViewController will control the about author view in the storyboard. This class loads the webpage from the index.html into the webkit View. The user will be able to dismiss the view by clicking the back navigation about app button.
 */
class AboutAuthorViewController: UIViewController
{
    
    @IBOutlet weak var webView: WKWebView!
    
    //Implementing the viewDidLoad function
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //setting the navigation title to About Author
        navigationItem.title = "About Author"
        
        //Create a path to the index.html "data" file bundle under the "html" folder
        
        let path = Bundle.main.path(forResource: "index", ofType: "html")!
        let data : Data = try! Data(contentsOf: URL(fileURLWithPath: path))
        let html = NSString(data: data, encoding: String.Encoding.utf8.rawValue)
        
        //Load the webView outlet with the content of the index.html file
        webView.loadHTMLString(html! as String, baseURL: Bundle.main.bundleURL)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
