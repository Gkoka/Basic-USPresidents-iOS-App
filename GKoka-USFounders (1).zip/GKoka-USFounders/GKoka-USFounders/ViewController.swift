//
//  ViewController.swift
//  GKoka-USFounders
//
//  Created by Naga Gayatri Koka on 9/25/18.
//  Copyright © 2018 Naga Gayatri Koka. All rights reserved.
/*
Author:     Naga Gayatri Koka
Z-ID:       Z1823454
Course:     CSCI 521, Fall 2018
Objectives: This is the third app for CSCI 321/521, FALL 2018 with the following learning objectives:
1. Learn how to read data from a property list and display on the
 table/list view.
2. Learn how to pass data from one view to other view.
5.  This app contains a total of 3 views displaying a welcome message,
pictures as per user interaction and also displays the information
about the app as well as the author of the app.

Due: Friday, 11:59 pm
*/

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

