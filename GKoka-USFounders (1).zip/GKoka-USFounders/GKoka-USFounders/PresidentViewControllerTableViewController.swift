//
//  PresidentViewControllerTableViewController.swift
//  GKoka-USFounders
//
//  Created by Gayatri on 01/10/18.
//  Copyright © 2018 Naga Gayatri Koka. All rights reserved.
/*
 Author:     Naga Gayatri Koka
 Z-ID:       Z1823454
 Course:     CSCI 521, Fall 2018
 Description: This is third app to develop by IOS Course students. The description is as follows
 1) This app uses tableViewController to display 7 US founders image, name and years of work. It displays the detail in the form of a table where each founder details displayed in each row. When a row is selected then the view will transfer to a detail view.
 2) Detail view consists of details about the Founder selected. It displays Image,title, political party and spouse name. It also has info light button on the bottom right cornor when this button is pressed the view will transfer to about app view.
 3) The about app has Done button, text view and about author button. When done button is pressed the view will transfer to the detail view. The text view consists of details about the application. when about author button is pressed view will transfer to about author view.
 4) About author view has webkit view which displays details of author who developed the application. Those details are presented in the form of a webpage.
 
 Due: Friday, 10/05/2018 11:59 pm
 */

import UIKit

/*PresidentViewControllerTableViewController will read the details of the US founders from the property list called USFounders.plist. It also loads the data in to each of table cell identified by "CELL".*/
class PresidentViewControllerTableViewController: UITableViewController {
    
    //Variable to store US founders data
    var presidentObject = [Presidents]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Call to read property list data into president object
        readPropertyList()
        
        //Set the height of each cell to 100
        self.tableView.rowHeight = 100
    }
    
    /* readPropertyList function will extract the data from the property list and stores it in presidentObject.
     */
    func readPropertyList ()
    {
        //Getting the location of the property list and loading it into array and printing it
        let path = Bundle.main.path(forResource: "USFounders", ofType: "plist")!
        let founderArray : NSArray = NSArray(contentsOfFile: path)!
        print("\(founderArray)")
        
        //Accessing each dictionary in item
        for item in founderArray
        {
            //Converting from any type to dictionary type
            let dictionary : [String : String] = (item as? Dictionary)!
            let president_name = dictionary["Name"]
            let president_title = dictionary["Title"]
            let year = dictionary["Years"]
            let president_spouse = dictionary["Spouse"]
            let political_party = dictionary["Party"]
            let cell_image = dictionary["Image-cell"]
            let president_image = dictionary["Image"]
            
            //Appending data into presidentObject
            presidentObject.append(Presidents(Name : president_name!, Title : president_title!, Years : year!, Spouse : president_spouse!, Party : political_party!, Image_cell : cell_image!, Image : president_image!))
        }
    }//readPropertyList
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    //This function is to inform the table controller about the number of coloumns needed for the table cell
    override func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1
    }

    //This function is to inform the table controller about the number of rows needed for the table cell
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return presidentObject.count
    }

    //This function will now load the data into each table cell where each US Founders data will present.
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        //Accessing president object
        let president : Presidents = presidentObject[indexPath.row]
        
        //Accessing the table cell
        let cell = tableView.dequeueReusableCell(withIdentifier: "CELL", for: indexPath) as! TableViewCell
        
        //Configure the cell
        //Place cell image, president name and years in the table cell
        let cellImageName = UIImage(named: president.Image_cell)
        cell.cellImageView.image = cellImageName
        cell.cellTitle.text = president.Name
        cell.cellSubTitle.text = president.Years

        //Returning the cell after configured for each founder
        return cell
    }
    
    //Prepare function will send the data from the table cell to detail view
    //It uses segue called Detailview to send the data
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "Detailview")//Checking the segue
        {
            let destVC = segue.destination as! DetailViewController
            
            //Sending the data of the selected row only
            if let indexPath = self.tableView.indexPathForSelectedRow
            {
                //Accessing the president object
                let president: Presidents = presidentObject[indexPath.row]
                
                //Assigning the values to the variables present in the detail view controller
                destVC.tvPresidentImage = president.Image
                destVC.tvParty = president.Party
                destVC.tvSpouse = president.Spouse
                destVC.tvTitle = president.Title
                destVC.tvPresidentName = president.Name
            }
        }
    }//Prepare
}//PresidentViewControllerTableViewController
